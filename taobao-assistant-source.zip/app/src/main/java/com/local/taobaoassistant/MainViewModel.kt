package com.local.taobaoassistant

import android.accessibilityservice.AccessibilityServiceInfo
import android.app.AlarmManager
import android.app.Application
import android.content.Context
import android.view.accessibility.AccessibilityManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.local.taobaoassistant.data.TaskRepository
import com.local.taobaoassistant.domain.PurchaseTask
import com.local.taobaoassistant.domain.TaskStatus
import com.local.taobaoassistant.domain.TaskValidator
import com.local.taobaoassistant.domain.ValidationResult
import com.local.taobaoassistant.notifications.NotificationController
import com.local.taobaoassistant.scheduling.TaskScheduler
import com.local.taobaoassistant.service.TaobaoAccessibilityService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class PermissionState(
    val accessibilityEnabled: Boolean,
    val exactAlarmsAllowed: Boolean,
    val notificationsEnabled: Boolean,
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = TaskRepository(application)
    private val scheduler = TaskScheduler(application)
    private val notifications = NotificationController(application)

    val task: StateFlow<PurchaseTask?> = repository.task.stateIn(
        scope = viewModelScope,
        started = SharingStarted.Eagerly,
        initialValue = null,
    )

    val permissions = MutableStateFlow(readPermissions())
    val message = MutableStateFlow<String?>(null)

    fun refreshPermissions() {
        permissions.value = readPermissions()
    }

    fun saveTask(
        itemUrl: String,
        skuText: String,
        triggerAtMillis: Long,
        confirmed: Boolean,
    ) {
        val validation = TaskValidator.validate(
            itemUrl = itemUrl,
            skuText = skuText,
            triggerAtMillis = triggerAtMillis,
            nowMillis = System.currentTimeMillis(),
        )
        if (validation is ValidationResult.Invalid) {
            message.value = validation.errors.joinToString("\n", transform = { it.message })
            return
        }
        if (!confirmed) {
            message.value = "请先确认到点自动提交订单"
            return
        }
        if (!scheduler.canScheduleExactAlarms()) {
            message.value = "请先允许“闹钟和提醒”权限"
            return
        }

        val savedTask = PurchaseTask(
            itemUrl = itemUrl.trim(),
            triggerAtMillis = triggerAtMillis,
            skuText = skuText.trim(),
        )
        viewModelScope.launch {
            repository.save(savedTask)
            val scheduled = runCatching { scheduler.schedule(savedTask) }.getOrDefault(false)
            refreshPermissions()
            if (!scheduled) {
                val error = "无法安排精确闹钟，请检查系统权限"
                repository.updateStatus(TaskStatus.Failed, error)
                message.value = error
                return@launch
            }
            val warnings = buildList {
                if (!permissions.value.accessibilityEnabled) {
                    add("无障碍服务未开启，到点将无法执行")
                }
                if (!permissions.value.notificationsEnabled) {
                    add("通知未开启，将收不到提醒和结果")
                }
            }
            message.value = buildString {
                append("任务已保存，开售前 2 分钟会提醒你解锁手机")
                if (warnings.isNotEmpty()) {
                    append("；")
                    append(warnings.joinToString("；"))
                }
            }
        }
    }

    fun cancelTask() {
        scheduler.cancel()
        TaobaoAccessibilityService.instance?.cancelAutomation()
        viewModelScope.launch {
            repository.clear()
            message.value = "任务已取消"
        }
    }

    fun dismissMessage() {
        message.value = null
    }

    private fun readPermissions(): PermissionState {
        val context = getApplication<Application>()
        val accessibilityManager = context.getSystemService(AccessibilityManager::class.java)
        val accessibilityEnabled = accessibilityManager
            .getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .any { info ->
                info.resolveInfo.serviceInfo.packageName == context.packageName &&
                    info.resolveInfo.serviceInfo.name == TaobaoAccessibilityService::class.java.name
            }
        val alarmManager = context.getSystemService(AlarmManager::class.java)
        return PermissionState(
            accessibilityEnabled = accessibilityEnabled,
            exactAlarmsAllowed = alarmManager.canScheduleExactAlarms(),
            notificationsEnabled = notifications.areNotificationsEnabled(),
        )
    }
}

