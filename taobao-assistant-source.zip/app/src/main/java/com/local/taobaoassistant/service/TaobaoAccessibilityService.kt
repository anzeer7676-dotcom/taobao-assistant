package com.local.taobaoassistant.service

import android.accessibilityservice.AccessibilityService
import android.app.KeyguardManager
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.local.taobaoassistant.automation.AutomationEngine
import com.local.taobaoassistant.automation.EngineEffect
import com.local.taobaoassistant.automation.UiNode
import com.local.taobaoassistant.automation.UiSnapshot
import com.local.taobaoassistant.data.TaskRepository
import com.local.taobaoassistant.domain.PurchaseTask
import com.local.taobaoassistant.domain.TaskStatus
import com.local.taobaoassistant.notifications.NotificationController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class TaobaoAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(
        SupervisorJob() + Dispatchers.IO.limitedParallelism(1),
    )
    private lateinit var repository: TaskRepository
    private lateinit var notifications: NotificationController

    private var activeTask: PurchaseTask? = null
    private var engine: AutomationEngine? = null
    private var deadlineMillis = 0L
    private var lastPersistedStatus: TaskStatus? = null
    private var nodeReferences: Map<String, AccessibilityNodeInfo> = emptyMap()

    private val evaluation = Runnable { evaluateScreen() }

    override fun onServiceConnected() {
        super.onServiceConnected()
        repository = TaskRepository(applicationContext)
        notifications = NotificationController(applicationContext)
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.packageName?.toString() != TAOBAO_PACKAGE || activeTask == null) return
        scheduleEvaluation(0)
    }

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        handler.removeCallbacks(evaluation)
        if (instance === this) instance = null
        scope.cancel()
        super.onDestroy()
    }

    fun startScheduledTask(task: PurchaseTask) {
        handler.post {
            begin(task)
        }
    }

    fun cancelAutomation() {
        handler.post {
            handler.removeCallbacks(evaluation)
            activeTask = null
            engine = null
            nodeReferences = emptyMap()
        }
    }

    private fun begin(task: PurchaseTask) {
        handler.removeCallbacks(evaluation)
        activeTask = task

        val powerManager = getSystemService(PowerManager::class.java)
        val keyguardManager = getSystemService(KeyguardManager::class.java)
        if (!powerManager.isInteractive || keyguardManager.isKeyguardLocked) {
            finish(
                TaskStatus.Failed,
                "手机处于锁屏或息屏状态，请解锁后再运行任务",
                notify = true,
            )
            return
        }

        engine = AutomationEngine().also { it.start(task, System.currentTimeMillis()) }
        lastPersistedStatus = null
        deadlineMillis = maxOf(
            task.triggerAtMillis + POST_SALE_TIMEOUT_MILLIS,
            System.currentTimeMillis() + MIN_RUN_TIMEOUT_MILLIS,
        )
        persistStatus(TaskStatus.LaunchingTaobao)

        if (!launchTaobao(task.itemUrl)) {
            finish(TaskStatus.Failed, "无法打开淘宝商品页，请确认已安装淘宝", notify = true)
            return
        }
        scheduleEvaluation(POLL_INTERVAL_MILLIS)
    }

    private fun launchTaobao(itemUrl: String): Boolean {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(itemUrl)).apply {
            setPackage(TAOBAO_PACKAGE)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        }
        if (packageManager.resolveActivity(intent, 0) == null) return false
        return try {
            startActivity(intent)
            true
        } catch (_: RuntimeException) {
            false
        }
    }

    private fun evaluateScreen() {
        val currentEngine = engine ?: return
        val now = System.currentTimeMillis()
        if (now > deadlineMillis) {
            finish(TaskStatus.Failed, "自动化超时，未到达待支付页面", notify = true)
            return
        }

        val snapshot = readSnapshot()
        val effect = currentEngine.onSnapshot(snapshot.ui, now)
        persistStatus(currentEngine.status)

        when (effect) {
            EngineEffect.LaunchTaobao,
            EngineEffect.Wait,
            -> scheduleEvaluation(POLL_INTERVAL_MILLIS)

            is EngineEffect.Click -> {
                val reference = nodeReferences[effect.node.id]
                val clicked = reference?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true
                if (clicked) {
                    scheduleEvaluation(ACTION_SETTLE_MILLIS)
                } else {
                    finish(TaskStatus.Failed, "页面按钮无法点击，自动化已停止", notify = true)
                }
            }

            is EngineEffect.Stop -> {
                val message = when (effect.status) {
                    TaskStatus.AwaitingPayment -> "订单已提交，请打开淘宝完成支付"
                    else -> effect.reason
                }
                finish(effect.status, message, notify = true)
            }
        }
    }

    private fun readSnapshot(): ReadSnapshot {
        val root = rootInActiveWindow
        val references = mutableMapOf<String, AccessibilityNodeInfo>()
        val nodes = root?.let { collectNodes(it, "0", references) }.orEmpty()
        val powerManager = getSystemService(PowerManager::class.java)
        val keyguardManager = getSystemService(KeyguardManager::class.java)
        nodeReferences = references
        return ReadSnapshot(
            UiSnapshot(
                packageName = root?.packageName?.toString().orEmpty(),
                nodes = nodes,
                keyguardLocked = !powerManager.isInteractive || keyguardManager.isKeyguardLocked,
            ),
        )
    }

    private fun collectNodes(
        node: AccessibilityNodeInfo,
        path: String,
        references: MutableMap<String, AccessibilityNodeInfo>,
    ): List<UiNode> {
        if (!node.isVisibleToUser) return emptyList()

        val result = mutableListOf<UiNode>()
        val childTexts = mutableListOf<String>()
        for (index in 0 until node.childCount) {
            val child = node.getChild(index) ?: continue
            childTexts += collectNodes(child, "$path/$index", references)
                .map(UiNode::text)
                .filter(String::isNotBlank)
        }

        val text = node.text?.toString().orEmpty()
        val description = node.contentDescription?.toString().orEmpty()
        if (node.isClickable) {
            references[path] = node
            val visibleLabels = buildList {
                if (text.isNotBlank()) add(text)
                if (description.isNotBlank()) add(description)
                addAll(childTexts)
            }.distinct()
            visibleLabels.forEach { label ->
                result += UiNode(
                    id = path,
                    text = label,
                    contentDescription = description,
                    clickable = true,
                    enabled = node.isEnabled,
                )
            }
        } else if (text.isNotBlank() || description.isNotBlank()) {
            result += UiNode(
                id = path,
                text = text,
                contentDescription = description,
                clickable = false,
                enabled = node.isEnabled,
            )
        }
        return result
    }

    private fun persistStatus(status: TaskStatus, error: String? = null) {
        if (status == lastPersistedStatus && error == null) return
        lastPersistedStatus = status
        scope.launch {
            repository.updateStatus(status, error)
        }
    }

    private fun finish(status: TaskStatus, message: String, notify: Boolean) {
        handler.removeCallbacks(evaluation)
        val shouldNotify = activeTask != null && notify
        activeTask = null
        engine = null
        nodeReferences = emptyMap()
        scope.launch {
            repository.updateStatus(status, if (status == TaskStatus.Failed) message else null)
            if (shouldNotify) {
                if (status == TaskStatus.AwaitingPayment) {
                    notifications.postResult("等待支付", message)
                } else {
                    notifications.postProblem(message)
                }
            }
        }
        Log.i(TAG, "Automation finished: $status")
    }

    private fun scheduleEvaluation(delayMillis: Long) {
        handler.removeCallbacks(evaluation)
        handler.postDelayed(evaluation, delayMillis)
    }

    private data class ReadSnapshot(
        val ui: UiSnapshot,
    )

    companion object {
        private const val TAG = "TaobaoAssistant"
        private const val TAOBAO_PACKAGE = "com.taobao.taobao"
        private const val POLL_INTERVAL_MILLIS = 250L
        private const val ACTION_SETTLE_MILLIS = 450L
        private const val POST_SALE_TIMEOUT_MILLIS = 20_000L
        private const val MIN_RUN_TIMEOUT_MILLIS = 25_000L

        @Volatile
        var instance: TaobaoAccessibilityService? = null
            private set
    }
}
