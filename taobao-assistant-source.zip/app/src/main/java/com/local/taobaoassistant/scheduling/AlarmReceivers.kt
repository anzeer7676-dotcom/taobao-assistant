package com.local.taobaoassistant.scheduling

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.local.taobaoassistant.data.TaskRepository
import com.local.taobaoassistant.notifications.NotificationController
import com.local.taobaoassistant.service.TaobaoAccessibilityService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import com.local.taobaoassistant.domain.TaskStatus

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                TaskRepository(context.applicationContext).task.first()?.let { task ->
                    if (task.status == TaskStatus.Scheduled) {
                        val repository = TaskRepository(context.applicationContext)
                        repository.updateStatus(TaskStatus.Preflight)
                        NotificationController(context.applicationContext).postReminder(task)
                    }
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}

class AutomationAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val appContext = context.applicationContext
                val repository = TaskRepository(appContext)
                val task = repository.task.first()
                if (task == null ||
                    (task.status != TaskStatus.Scheduled && task.status != TaskStatus.Preflight)
                ) return@launch

                val service = TaobaoAccessibilityService.instance
                if (service == null) {
                    val reason = "无障碍服务未运行，请检查并重新开启"
                    repository.updateStatus(TaskStatus.Failed, reason)
                    NotificationController(appContext).postProblem(reason)
                } else {
                    service.startScheduledTask(task)
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED &&
            intent.action != Intent.ACTION_MY_PACKAGE_REPLACED
        ) {
            return
        }

        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val appContext = context.applicationContext
                val task = TaskRepository(appContext).task.first()
                if (task != null &&
                    (task.status == TaskStatus.Scheduled || task.status == TaskStatus.Preflight) &&
                    task.triggerAtMillis > System.currentTimeMillis()
                ) {
                    TaskScheduler(appContext).schedule(task)
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}

