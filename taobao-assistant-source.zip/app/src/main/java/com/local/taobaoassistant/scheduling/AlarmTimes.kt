package com.local.taobaoassistant.scheduling

object AlarmTimes {
    fun reminderAt(saleAtMillis: Long): Long = saleAtMillis - 120_000

    fun automationAt(saleAtMillis: Long): Long = saleAtMillis - 15_000
}
