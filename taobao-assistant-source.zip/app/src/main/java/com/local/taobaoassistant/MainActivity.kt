package com.local.taobaoassistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.local.taobaoassistant.ui.AssistantScreen

class MainActivity : ComponentActivity() {
    private val viewModel: MainViewModel by viewModels()
    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) {
        if (!NotificationManagerCompat.from(this).areNotificationsEnabled()) {
            openNotificationSettings()
        }
        viewModel.refreshPermissions()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val task by viewModel.task.collectAsState()
            val permissions by viewModel.permissions.collectAsState()
            val message by viewModel.message.collectAsState()

            AssistantScreen(
                task = task,
                permissions = permissions,
                message = message,
                onSave = viewModel::saveTask,
                onCancel = viewModel::cancelTask,
                onDismissMessage = viewModel::dismissMessage,
                onAccessibilitySettings = {
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                },
                onExactAlarmSettings = ::openExactAlarmSettings,
                onNotificationSettings = ::requestNotificationsOrOpenSettings,
                onAutoStartSettings = ::openAutoStartSettings,
                onBackgroundPopupSettings = ::openBackgroundPopupSettings,
                onBatterySettings = {
                    launchWithFallback(
                        primary = MiuiSettings.batterySettingsIntent(),
                        fallback = MiuiSettings.appDetailsIntent(this),
                    )
                },
            )
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshPermissions()
    }

    private fun openExactAlarmSettings() {
        launchWithFallback(
            primary = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                data = Uri.parse("package:$packageName")
            },
            fallback = MiuiSettings.appDetailsIntent(this),
        )
    }

    private fun requestNotificationsOrOpenSettings() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS,
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            openNotificationSettings()
        }
    }

    private fun openNotificationSettings() {
        startActivity(
            Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
            },
        )
    }

    private fun openAutoStartSettings() {
        launchWithFallback(
            primary = MiuiSettings.autoStartIntent(),
            fallback = MiuiSettings.appDetailsIntent(this),
        )
    }

    private fun openBackgroundPopupSettings() {
        launchWithFallback(
            primary = MiuiSettings.backgroundPopupIntent(this),
            fallback = MiuiSettings.appDetailsIntent(this),
        )
    }

    private fun launchWithFallback(primary: Intent, fallback: Intent) {
        val opened = runCatching { startActivity(primary) }.isSuccess
        if (!opened) startActivity(fallback)
    }
}

