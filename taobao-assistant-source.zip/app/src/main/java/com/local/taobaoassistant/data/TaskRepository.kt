package com.local.taobaoassistant.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.local.taobaoassistant.domain.PurchaseTask
import com.local.taobaoassistant.domain.TaskStatus
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.taskDataStore by preferencesDataStore(name = "purchase_task")

class TaskRepository(private val context: Context) {
    val task: Flow<PurchaseTask?> = context.taskDataStore.data.map { preferences ->
        val itemUrl = preferences[Keys.ITEM_URL] ?: return@map null
        PurchaseTask(
            itemUrl = itemUrl,
            triggerAtMillis = preferences[Keys.TRIGGER_AT] ?: return@map null,
            skuText = preferences[Keys.SKU_TEXT].orEmpty(),
            status = preferences[Keys.STATUS]
                ?.let { stored -> TaskStatus.entries.firstOrNull { it.name == stored } }
                ?: TaskStatus.Scheduled,
            error = preferences[Keys.ERROR],
        )
    }

    suspend fun save(task: PurchaseTask) {
        context.taskDataStore.edit { preferences ->
            preferences[Keys.ITEM_URL] = task.itemUrl
            preferences[Keys.TRIGGER_AT] = task.triggerAtMillis
            preferences[Keys.SKU_TEXT] = task.skuText
            preferences[Keys.STATUS] = task.status.name
            if (task.error == null) {
                preferences.remove(Keys.ERROR)
            } else {
                preferences[Keys.ERROR] = task.error
            }
        }
    }

    suspend fun updateStatus(status: TaskStatus, error: String? = null) {
        context.taskDataStore.edit { preferences ->
            if (preferences[Keys.ITEM_URL] == null) return@edit
            preferences[Keys.STATUS] = status.name
            if (error == null) {
                preferences.remove(Keys.ERROR)
            } else {
                preferences[Keys.ERROR] = error
            }
        }
    }

    suspend fun clear() {
        context.taskDataStore.edit { it.clear() }
    }

    private object Keys {
        val ITEM_URL = stringPreferencesKey("item_url")
        val TRIGGER_AT = longPreferencesKey("trigger_at")
        val SKU_TEXT = stringPreferencesKey("sku_text")
        val STATUS = stringPreferencesKey("status")
        val ERROR = stringPreferencesKey("error")
    }
}

