package com.local.taobaoassistant.domain

data class PurchaseTask(
    val itemUrl: String,
    val triggerAtMillis: Long,
    val skuText: String,
    val status: TaskStatus = TaskStatus.Scheduled,
    val error: String? = null,
)

enum class TaskStatus {
    Scheduled,
    Preflight,
    LaunchingTaobao,
    SelectingSku,
    Checkout,
    Submitting,
    AwaitingPayment,
    Failed,
    Cancelled,
}

