package com.local.taobaoassistant.ui

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.local.taobaoassistant.PermissionState
import com.local.taobaoassistant.domain.PurchaseTask
import com.local.taobaoassistant.domain.TaskStatus
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
fun AssistantScreen(
    task: PurchaseTask?,
    permissions: PermissionState,
    message: String?,
    onSave: (String, String, Long, Boolean) -> Unit,
    onCancel: () -> Unit,
    onDismissMessage: () -> Unit,
    onAccessibilitySettings: () -> Unit,
    onExactAlarmSettings: () -> Unit,
    onNotificationSettings: () -> Unit,
    onAutoStartSettings: () -> Unit,
    onBackgroundPopupSettings: () -> Unit,
    onBatterySettings: () -> Unit,
) {
    val colors = lightColorScheme(
        primary = Color(0xFFB33A20),
        secondary = Color(0xFF5B5957),
        background = Color(0xFFFFF8F4),
        surface = Color(0xFFFFFFFF),
    )
    MaterialTheme(colorScheme = colors) {
        Surface(modifier = Modifier.fillMaxSize()) {
            AssistantContent(
                task = task,
                permissions = permissions,
                message = message,
                onSave = onSave,
                onCancel = onCancel,
                onDismissMessage = onDismissMessage,
                onAccessibilitySettings = onAccessibilitySettings,
                onExactAlarmSettings = onExactAlarmSettings,
                onNotificationSettings = onNotificationSettings,
                onAutoStartSettings = onAutoStartSettings,
                onBackgroundPopupSettings = onBackgroundPopupSettings,
                onBatterySettings = onBatterySettings,
            )
        }
    }
}

@Composable
private fun AssistantContent(
    task: PurchaseTask?,
    permissions: PermissionState,
    message: String?,
    onSave: (String, String, Long, Boolean) -> Unit,
    onCancel: () -> Unit,
    onDismissMessage: () -> Unit,
    onAccessibilitySettings: () -> Unit,
    onExactAlarmSettings: () -> Unit,
    onNotificationSettings: () -> Unit,
    onAutoStartSettings: () -> Unit,
    onBackgroundPopupSettings: () -> Unit,
    onBatterySettings: () -> Unit,
) {
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }
    var itemUrl by rememberSaveable { mutableStateOf("") }
    var skuText by rememberSaveable { mutableStateOf("") }
    var triggerAtMillis by rememberSaveable {
        mutableLongStateOf(System.currentTimeMillis() + 5 * 60_000L)
    }
    var confirmed by rememberSaveable { mutableStateOf(false) }

    LaunchedEffect(task?.itemUrl, task?.triggerAtMillis, task?.skuText) {
        task?.let {
            itemUrl = it.itemUrl
            skuText = it.skuText
            triggerAtMillis = it.triggerAtMillis
        }
    }
    LaunchedEffect(message) {
        message?.let {
            snackbarHostState.showSnackbar(it)
            onDismissMessage()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp, vertical = 20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Text(
                text = "淘宝抢购助手",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
            )
            Text(
                text = "单品、单件、自动提交到待支付。支付和验证码始终由你完成。",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.secondary,
            )

            PermissionCard(
                permissions = permissions,
                onAccessibilitySettings = onAccessibilitySettings,
                onExactAlarmSettings = onExactAlarmSettings,
                onNotificationSettings = onNotificationSettings,
            )

            Card(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Text("预约任务", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    OutlinedTextField(
                        value = itemUrl,
                        onValueChange = { itemUrl = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("淘宝或天猫商品链接") },
                        singleLine = true,
                    )
                    OutlinedTextField(
                        value = skuText,
                        onValueChange = { skuText = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("SKU 可见文字") },
                        supportingText = { Text("多项规格用 / 分隔，例如：黑色 / 256GB") },
                        singleLine = true,
                    )
                    OutlinedButton(
                        onClick = {
                            showDateTimePicker(context, triggerAtMillis) { picked ->
                                triggerAtMillis = picked
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Text("开售时间：${formatDateTime(triggerAtMillis)}")
                    }
                    Row(verticalAlignment = Alignment.Top) {
                        Checkbox(
                            checked = confirmed,
                            onCheckedChange = { confirmed = it },
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = "我确认到点自动提交订单，支付由本人完成。链接、规格或页面变化可能导致失败。",
                            modifier = Modifier.padding(top = 12.dp),
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                    Button(
                        onClick = {
                            onSave(itemUrl, skuText, triggerAtMillis, confirmed)
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Text(if (task == null) "保存并安排任务" else "更新并重新安排")
                    }
                }
            }

            if (task != null) {
                TaskStatusCard(task = task, onCancel = onCancel)
            }

            MiuiCard(
                onAutoStartSettings = onAutoStartSettings,
                onBackgroundPopupSettings = onBackgroundPopupSettings,
                onBatterySettings = onBatterySettings,
            )

            Text(
                text = "本应用不保存淘宝账号密码，不处理验证码或风控验证，也不操作支付按钮。请遵守淘宝平台规则，仅用于个人购买。",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.padding(bottom = 16.dp),
            )
        }
    }
}

@Composable
private fun PermissionCard(
    permissions: PermissionState,
    onAccessibilitySettings: () -> Unit,
    onExactAlarmSettings: () -> Unit,
    onNotificationSettings: () -> Unit,
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text("必要权限", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            PermissionRow("无障碍服务", permissions.accessibilityEnabled, onAccessibilitySettings)
            PermissionRow("精确闹钟", permissions.exactAlarmsAllowed, onExactAlarmSettings)
            PermissionRow("通知", permissions.notificationsEnabled, onNotificationSettings)
        }
    }
}

@Composable
private fun PermissionRow(label: String, enabled: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = if (enabled) "$label 已开启" else "$label 未开启",
            modifier = Modifier.weight(1f),
            color = if (enabled) Color(0xFF2E6B3D) else MaterialTheme.colorScheme.error,
        )
        TextButton(onClick = onClick) {
            Text(if (enabled) "检查设置" else "去开启")
        }
    }
}

@Composable
private fun TaskStatusCard(task: PurchaseTask, onCancel: () -> Unit) {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(task.status, task.triggerAtMillis) {
        while (true) {
            now = System.currentTimeMillis()
            delay(1_000)
        }
    }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "当前任务",
                    modifier = Modifier.weight(1f),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                )
                if (task.status == TaskStatus.Preflight ||
                    task.status == TaskStatus.LaunchingTaobao ||
                    task.status == TaskStatus.SelectingSku ||
                    task.status == TaskStatus.Checkout ||
                    task.status == TaskStatus.Submitting
                ) {
                    CircularProgressIndicator(modifier = Modifier.height(20.dp).width(20.dp))
                }
            }
            Text(
                text = task.itemUrl,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodySmall,
            )
            Text("SKU：${task.skuText}")
            Text("状态：${task.status.displayName()}")
            if ((task.status == TaskStatus.Scheduled || task.status == TaskStatus.Preflight) &&
                task.triggerAtMillis > now
            ) {
                Text(
                    text = "距开售：${formatRemaining(task.triggerAtMillis - now)}",
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold,
                )
            }
            task.error?.let {
                Text(it, color = MaterialTheme.colorScheme.error)
            }
            OutlinedButton(onClick = onCancel, modifier = Modifier.fillMaxWidth()) {
                Text("取消任务")
            }
        }
    }
}

@Composable
private fun MiuiCard(
    onAutoStartSettings: () -> Unit,
    onBackgroundPopupSettings: () -> Unit,
    onBatterySettings: () -> Unit,
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text("小米 / 红米设置", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Text(
                "为保证开售时能启动，请允许自启动、后台弹出界面，并将省电策略设为“无限制”。",
                style = MaterialTheme.typography.bodySmall,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onAutoStartSettings, modifier = Modifier.weight(1f)) {
                    Text("自启动")
                }
                OutlinedButton(onClick = onBackgroundPopupSettings, modifier = Modifier.weight(1f)) {
                    Text("后台界面")
                }
            }
            OutlinedButton(onClick = onBatterySettings, modifier = Modifier.fillMaxWidth()) {
                Text("省电策略")
            }
        }
    }
}

private fun showDateTimePicker(
    context: android.content.Context,
    initialMillis: Long,
    onPicked: (Long) -> Unit,
) {
    val calendar = Calendar.getInstance().apply { timeInMillis = initialMillis }
    DatePickerDialog(
        context,
        { _, year, month, day ->
            val selected = Calendar.getInstance().apply {
                timeInMillis = initialMillis
                set(Calendar.YEAR, year)
                set(Calendar.MONTH, month)
                set(Calendar.DAY_OF_MONTH, day)
            }
            TimePickerDialog(
                context,
                { _, hour, minute ->
                    selected.set(Calendar.HOUR_OF_DAY, hour)
                    selected.set(Calendar.MINUTE, minute)
                    selected.set(Calendar.SECOND, 0)
                    selected.set(Calendar.MILLISECOND, 0)
                    if (selected.timeInMillis <= System.currentTimeMillis()) {
                        Toast.makeText(context, "请选择未来的开售时间", Toast.LENGTH_SHORT).show()
                    } else {
                        onPicked(selected.timeInMillis)
                    }
                },
                calendar.get(Calendar.HOUR_OF_DAY),
                calendar.get(Calendar.MINUTE),
                true,
            ).show()
        },
        calendar.get(Calendar.YEAR),
        calendar.get(Calendar.MONTH),
        calendar.get(Calendar.DAY_OF_MONTH),
    ).show()
}

private fun formatDateTime(millis: Long): String =
    SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.CHINA).format(Date(millis))

private fun formatRemaining(remainingMillis: Long): String {
    val totalSeconds = (remainingMillis.coerceAtLeast(0) / 1000)
    val hours = totalSeconds / 3600
    val minutes = (totalSeconds % 3600) / 60
    val seconds = totalSeconds % 60
    return if (hours > 0) {
        "${hours}小时${minutes}分${seconds}秒"
    } else {
        "${minutes}分${seconds}秒"
    }
}

private fun TaskStatus.displayName(): String = when (this) {
    TaskStatus.Scheduled -> "已安排"
    TaskStatus.Preflight -> "开售前提醒"
    TaskStatus.LaunchingTaobao -> "正在打开淘宝"
    TaskStatus.SelectingSku -> "正在选择规格"
    TaskStatus.Checkout -> "正在确认订单"
    TaskStatus.Submitting -> "正在提交订单"
    TaskStatus.AwaitingPayment -> "等待支付"
    TaskStatus.Failed -> "执行失败"
    TaskStatus.Cancelled -> "已取消"
}
