package com.local.taobaoassistant.scheduling

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.local.taobaoassistant.domain.PurchaseTask

class TaskScheduler(private val context: Context) {
    private val alarmManager = context.getSystemService(AlarmManager::class.java)

    fun canScheduleExactAlarms(): Boolean =
        alarmManager.canScheduleExactAlarms()

    fun schedule(task: PurchaseTask): Boolean {
        if (!canScheduleExactAlarms()) return false

        val now = System.currentTimeMillis()
        val reminderAt = AlarmTimes.reminderAt(task.triggerAtMillis)
        if (reminderAt > now) {
            alarmManager.setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                reminderAt,
                pendingIntent(ReminderReceiver::class.java, REMINDER_REQUEST_CODE),
            )
        }

        val automationAt = maxOf(
            AlarmTimes.automationAt(task.triggerAtMillis),
            now + 500,
        )
        alarmManager.setExactAndAllowWhileIdle(
            AlarmManager.RTC_WAKEUP,
            automationAt,
            pendingIntent(AutomationAlarmReceiver::class.java, AUTOMATION_REQUEST_CODE),
        )
        return true
    }

    fun cancel() {
        alarmManager.cancel(pendingIntent(ReminderReceiver::class.java, REMINDER_REQUEST_CODE))
        alarmManager.cancel(pendingIntent(AutomationAlarmReceiver::class.java, AUTOMATION_REQUEST_CODE))
    }

    private fun pendingIntent(receiver: Class<*>, requestCode: Int): PendingIntent {
        val intent = Intent(context, receiver).setAction(receiver.name)
        return PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }

    private companion object {
        const val REMINDER_REQUEST_CODE = 2_001
        const val AUTOMATION_REQUEST_CODE = 2_002
    }
}

