package com.local.taobaoassistant.notifications

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.local.taobaoassistant.MainActivity
import com.local.taobaoassistant.R
import com.local.taobaoassistant.domain.PurchaseTask

class NotificationController(private val context: Context) {
    private val manager = context.getSystemService(NotificationManager::class.java)

    init {
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ID,
                "抢购任务",
                NotificationManager.IMPORTANCE_HIGH,
            ).apply {
                description = "开售提醒和自动化执行结果"
            },
        )
    }

    fun areNotificationsEnabled(): Boolean =
        NotificationManagerCompat.from(context).areNotificationsEnabled()

    fun postReminder(task: PurchaseTask) {
        post(
            title = "2 分钟后开售",
            text = "请解锁手机、保持网络连接，并确认淘宝已登录",
            id = NOTIFICATION_REMINDER,
        )
    }

    fun postProblem(message: String) {
        post(
            title = "抢购任务未完成",
            text = message,
            id = NOTIFICATION_RESULT,
        )
    }

    fun postResult(status: String, message: String) {
        post(
            title = status,
            text = message,
            id = NOTIFICATION_RESULT,
        )
    }

    private fun post(title: String, text: String, id: Int) {
        if (!areNotificationsEnabled()) return
        val openApp = PendingIntent.getActivity(
            context,
            0,
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(openApp)
            .setAutoCancel(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS,
            ) != PackageManager.PERMISSION_GRANTED
        ) return

        runCatching {
            NotificationManagerCompat.from(context).notify(id, notification)
        }
    }

    private companion object {
        const val CHANNEL_ID = "purchase_tasks"
        const val NOTIFICATION_REMINDER = 3_001
        const val NOTIFICATION_RESULT = 3_002
    }
}
