package com.local.taobaoassistant.automation

import com.local.taobaoassistant.domain.PurchaseTask
import com.local.taobaoassistant.domain.TaskStatus

data class UiNode(
    val id: String,
    val text: String,
    val contentDescription: String,
    val clickable: Boolean,
    val enabled: Boolean,
)

data class UiSnapshot(
    val packageName: String,
    val nodes: List<UiNode>,
    val keyguardLocked: Boolean,
)

sealed interface EngineEffect {
    data object LaunchTaobao : EngineEffect

    data object Wait : EngineEffect

    data class Click(
        val node: UiNode,
    ) : EngineEffect

    data class Stop(
        val status: TaskStatus,
        val reason: String,
    ) : EngineEffect
}

class AutomationEngine {
    var status: TaskStatus = TaskStatus.Scheduled
        private set

    private lateinit var task: PurchaseTask
    private var skuClickIssued = false
    private var skuLabels: List<String> = emptyList()
    private val clickedSkuLabels = mutableSetOf<String>()

    fun start(task: PurchaseTask, nowMillis: Long): EngineEffect {
        this.task = task
        skuClickIssued = false
        skuLabels = task.skuText
            .split(Regex("[/／|、]"))
            .map(::normalize)
            .filter(String::isNotEmpty)
        clickedSkuLabels.clear()
        status = TaskStatus.LaunchingTaobao
        return EngineEffect.LaunchTaobao
    }

    fun onSnapshot(snapshot: UiSnapshot, nowMillis: Long): EngineEffect {
        if (status == TaskStatus.Failed ||
            status == TaskStatus.AwaitingPayment ||
            status == TaskStatus.Cancelled
        ) {
            return EngineEffect.Wait
        }

        if (snapshot.packageName != TAOBAO_PACKAGE) {
            return EngineEffect.Wait
        }

        if (snapshot.keyguardLocked) {
            return fail("手机处于锁屏状态，请先解锁")
        }

        val visibleText = snapshot.nodes.map(::combinedText)
        if (visibleText.any { text -> CHALLENGE_MARKERS.any(text::contains) }) {
            return fail("检测到验证码或安全验证，自动化已停止")
        }
        if (visibleText.any { text -> STOP_MARKERS.any(text::contains) }) {
            return fail("商品已下架、售罄或当前不可购买")
        }
        if (visibleText.any { text -> PAYMENT_MARKERS.any(text::contains) }) {
            status = TaskStatus.AwaitingPayment
            return EngineEffect.Stop(TaskStatus.AwaitingPayment, "已到达待支付页面")
        }

        return when (status) {
            TaskStatus.LaunchingTaobao -> {
                if (nowMillis < task.triggerAtMillis) {
                    EngineEffect.Wait
                } else {
                    val buyButton = findClickable(snapshot, BUY_LABELS)
                    if (buyButton == null) {
                        EngineEffect.Wait
                    } else {
                        status = TaskStatus.SelectingSku
                        EngineEffect.Click(buyButton)
                    }
                }
            }

            TaskStatus.SelectingSku -> handleSkuSelection(snapshot)
            TaskStatus.Checkout -> handleCheckout(snapshot)
            TaskStatus.Submitting -> EngineEffect.Wait
            else -> EngineEffect.Wait
        }
    }

    private fun handleSkuSelection(snapshot: UiSnapshot): EngineEffect {
        if (!skuClickIssued) {
            val exactSku = snapshot.nodes.firstOrNull {
                normalize(it.text) == normalize(task.skuText)
            }
            if (exactSku != null) {
                if (!exactSku.clickable || !exactSku.enabled) {
                    return fail("目标规格当前不可购买")
                }
                clickedSkuLabels.addAll(skuLabels)
                skuClickIssued = true
                return EngineEffect.Click(exactSku)
            }

            val remainingLabels = skuLabels.filterNot(clickedSkuLabels::contains)
            val sku = snapshot.nodes.firstOrNull { node ->
                normalize(node.text) in remainingLabels
            } ?: return EngineEffect.Wait
            if (!sku.clickable || !sku.enabled) {
                return fail("目标规格当前不可购买")
            }

            clickedSkuLabels.add(normalize(sku.text))
            skuClickIssued = clickedSkuLabels.containsAll(skuLabels)
            return EngineEffect.Click(sku)
        }

        val confirm = findClickable(snapshot, CONFIRM_LABELS)
            ?: return EngineEffect.Wait
        status = TaskStatus.Checkout
        return EngineEffect.Click(confirm)
    }

    private fun handleCheckout(snapshot: UiSnapshot): EngineEffect {
        val submit = findClickable(snapshot, SUBMIT_LABELS)
            ?: return EngineEffect.Wait
        if (!hasSingleQuantityEvidence(snapshot)) {
            return fail("无法确认结算数量为 1，未提交订单")
        }
        status = TaskStatus.Submitting
        return EngineEffect.Click(submit)
    }

    private fun findClickable(snapshot: UiSnapshot, labels: Set<String>): UiNode? {
        val wanted = labels.map(::normalize).toSet()
        return snapshot.nodes.firstOrNull {
            it.clickable &&
                it.enabled &&
                normalize(it.text) in wanted
        }
    }

    private fun hasSingleQuantityEvidence(snapshot: UiSnapshot): Boolean =
        snapshot.nodes.any { node ->
            val text = combinedText(node)
            QUANTITY_ONE_MARKERS.any(text::contains)
        }

    private fun fail(reason: String): EngineEffect {
        status = TaskStatus.Failed
        return EngineEffect.Stop(TaskStatus.Failed, reason)
    }

    private fun combinedText(node: UiNode): String =
        normalize(node.text + node.contentDescription)

    private fun normalize(value: String): String =
        value.replace(Regex("\\s+"), "").lowercase()

    private companion object {
        const val TAOBAO_PACKAGE = "com.taobao.taobao"
        val BUY_LABELS = setOf("立即购买", "马上抢", "立即抢购")
        val CONFIRM_LABELS = setOf("确定", "立即购买", "马上抢", "立即抢购")
        val SUBMIT_LABELS = setOf("提交订单")
        val PAYMENT_MARKERS = setOf("立即支付", "确认付款", "收银台")
        val CHALLENGE_MARKERS = setOf(
            "安全验证",
            "验证码",
            "人机验证",
            "滑块",
            "风险提示",
            "账号异常",
            "请先登录",
            "登录后购买",
        )
        val STOP_MARKERS = setOf("已售罄", "已抢光", "商品已下架", "库存不足")
        val QUANTITY_ONE_MARKERS = setOf(
            "数量1",
            "数量:1",
            "数量：1",
            "件数1",
            "件数:1",
            "件数：1",
            "x1",
            "×1",
            "1件",
            "共1件",
        )
    }
}
