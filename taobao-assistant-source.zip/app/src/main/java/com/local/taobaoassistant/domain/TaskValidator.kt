package com.local.taobaoassistant.domain

import java.net.URI

enum class TaskField {
    URL,
    TRIGGER_TIME,
    SKU,
}

data class ValidationError(
    val field: TaskField,
    val message: String,
)

sealed interface ValidationResult {
    data object Valid : ValidationResult

    data class Invalid(
        val errors: List<ValidationError>,
    ) : ValidationResult
}

object TaskValidator {
    fun validate(
        itemUrl: String,
        skuText: String,
        triggerAtMillis: Long,
        nowMillis: Long,
    ): ValidationResult {
        val errors = buildList {
            if (!isTaobaoOrTmallUrl(itemUrl)) {
                add(ValidationError(TaskField.URL, "请填写淘宝或天猫商品链接"))
            }
            if (triggerAtMillis <= nowMillis) {
                add(ValidationError(TaskField.TRIGGER_TIME, "开售时间必须晚于当前时间"))
            }
            if (skuText.isBlank()) {
                add(ValidationError(TaskField.SKU, "请填写商品页面显示的完整 SKU 文字"))
            }
        }

        return if (errors.isEmpty()) {
            ValidationResult.Valid
        } else {
            ValidationResult.Invalid(errors)
        }
    }

    private fun isTaobaoOrTmallUrl(value: String): Boolean {
        val uri = runCatching { URI(value.trim()) }.getOrNull() ?: return false
        if (uri.scheme != "https" && uri.scheme != "http") return false
        val host = uri.host?.lowercase() ?: return false
        return host == "taobao.com" ||
            host.endsWith(".taobao.com") ||
            host == "tmall.com" ||
            host.endsWith(".tmall.com") ||
            host == "m.tb.cn" ||
            host == "e.tb.cn"
    }
}

