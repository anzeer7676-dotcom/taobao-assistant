package com.local.taobaoassistant.scheduling

import org.junit.Assert.assertEquals
import org.junit.Test

class AlarmTimesTest {
    private val saleAt = 1_700_000_300_000L

    @Test
    fun reminderIsTwoMinutesBeforeSale() {
        assertEquals(
            saleAt - 120_000,
            AlarmTimes.reminderAt(saleAt),
        )
    }

    @Test
    fun automationStartsFifteenSecondsBeforeSale() {
        assertEquals(
            saleAt - 15_000,
            AlarmTimes.automationAt(saleAt),
        )
    }
}
