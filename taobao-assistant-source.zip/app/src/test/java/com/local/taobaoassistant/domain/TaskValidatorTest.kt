package com.local.taobaoassistant.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TaskValidatorTest {
    private val now = 1_700_000_000_000L

    @Test
    fun acceptsTaobaoItemUrlWithFutureTimeAndSku() {
        val result = TaskValidator.validate(
            itemUrl = "https://item.taobao.com/item.htm?id=123",
            skuText = "黑色 / 256GB",
            triggerAtMillis = now + 60_000,
            nowMillis = now,
        )

        assertEquals(ValidationResult.Valid, result)
    }

    @Test
    fun acceptsTaobaoShareLink() {
        val result = TaskValidator.validate(
            itemUrl = "https://m.tb.cn/h.example",
            skuText = "黑色",
            triggerAtMillis = now + 60_000,
            nowMillis = now,
        )

        assertEquals(ValidationResult.Valid, result)
    }

    @Test
    fun rejectsUrlOutsideTaobaoAndTmall() {
        val result = TaskValidator.validate(
            itemUrl = "https://example.com/item?id=123",
            skuText = "黑色",
            triggerAtMillis = now + 60_000,
            nowMillis = now,
        )

        assertTrue(result is ValidationResult.Invalid)
        assertEquals(
            listOf(TaskField.URL),
            (result as ValidationResult.Invalid).errors.map { it.field },
        )
    }

    @Test
    fun rejectsScheduleThatHasAlreadyStarted() {
        val result = TaskValidator.validate(
            itemUrl = "https://item.taobao.com/item.htm?id=123",
            skuText = "黑色",
            triggerAtMillis = now,
            nowMillis = now,
        )

        assertTrue(result is ValidationResult.Invalid)
        assertEquals(
            listOf(TaskField.TRIGGER_TIME),
            (result as ValidationResult.Invalid).errors.map { it.field },
        )
    }

    @Test
    fun rejectsBlankSku() {
        val result = TaskValidator.validate(
            itemUrl = "https://item.taobao.com/item.htm?id=123",
            skuText = "   ",
            triggerAtMillis = now + 60_000,
            nowMillis = now,
        )

        assertTrue(result is ValidationResult.Invalid)
        assertEquals(
            listOf(TaskField.SKU),
            (result as ValidationResult.Invalid).errors.map { it.field },
        )
    }
}

