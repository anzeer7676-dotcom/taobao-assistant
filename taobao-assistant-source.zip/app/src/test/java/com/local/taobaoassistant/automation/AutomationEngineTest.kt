package com.local.taobaoassistant.automation

import com.local.taobaoassistant.domain.PurchaseTask
import com.local.taobaoassistant.domain.TaskStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AutomationEngineTest {
    private val saleAt = 1_700_000_300_000L
    private val task = PurchaseTask(
        itemUrl = "https://item.taobao.com/item.htm?id=123",
        triggerAtMillis = saleAt,
        skuText = "黑色 / 256GB",
    )

    private fun node(
        id: String,
        text: String,
        clickable: Boolean = true,
        enabled: Boolean = true,
    ) = UiNode(
        id = id,
        text = text,
        contentDescription = "",
        clickable = clickable,
        enabled = enabled,
    )

    private fun snapshot(vararg nodes: UiNode, keyguardLocked: Boolean = false) =
        UiSnapshot(
            packageName = "com.taobao.taobao",
            nodes = nodes.toList(),
            keyguardLocked = keyguardLocked,
        )

    @Test
    fun startLaunchesTaobaoAndMarksAutomationActive() {
        val engine = AutomationEngine()

        val effect = engine.start(task, saleAt - 15_000)

        assertEquals(EngineEffect.LaunchTaobao, effect)
        assertEquals(TaskStatus.LaunchingTaobao, engine.status)
    }

    @Test
    fun waitsWithoutClickingBuyButtonBeforeSaleTime() {
        val engine = AutomationEngine()
        engine.start(task, saleAt - 15_000)

        val effect = engine.onSnapshot(
            snapshot(node("buy", "立即购买")),
            saleAt - 1,
        )

        assertEquals(EngineEffect.Wait, effect)
        assertEquals(TaskStatus.LaunchingTaobao, engine.status)
    }

    @Test
    fun clicksBuyButtonAtSaleTime() {
        val engine = AutomationEngine()
        engine.start(task, saleAt - 15_000)

        val effect = engine.onSnapshot(snapshot(node("buy", "立即购买")), saleAt)

        assertTrue(effect is EngineEffect.Click)
        assertEquals("buy", (effect as EngineEffect.Click).node.id)
        assertEquals(TaskStatus.SelectingSku, engine.status)
    }

    @Test
    fun selectsExactSkuThenConfirmsSelection() {
        val engine = AutomationEngine()
        engine.start(task, saleAt - 15_000)
        engine.onSnapshot(snapshot(node("buy", "立即购买")), saleAt)
        val skuPage = snapshot(
            node("sku", "黑色 / 256GB"),
            node("confirm", "确定"),
        )

        val selectEffect = engine.onSnapshot(skuPage, saleAt + 100)
        val confirmEffect = engine.onSnapshot(skuPage, saleAt + 200)

        assertEquals("sku", (selectEffect as EngineEffect.Click).node.id)
        assertEquals("confirm", (confirmEffect as EngineEffect.Click).node.id)
        assertEquals(TaskStatus.Checkout, engine.status)
    }

    @Test
    fun selectsSkuDimensionsInOrderBeforeConfirming() {
        val engine = AutomationEngine()
        engine.start(task, saleAt - 15_000)
        engine.onSnapshot(snapshot(node("buy", "立即购买")), saleAt)
        val skuPage = snapshot(
            node("color", "黑色"),
            node("storage", "256GB"),
            node("confirm", "确定"),
        )

        val colorEffect = engine.onSnapshot(skuPage, saleAt + 100)
        val storageEffect = engine.onSnapshot(skuPage, saleAt + 200)
        val confirmEffect = engine.onSnapshot(skuPage, saleAt + 300)

        assertEquals("color", (colorEffect as EngineEffect.Click).node.id)
        assertEquals("storage", (storageEffect as EngineEffect.Click).node.id)
        assertEquals("confirm", (confirmEffect as EngineEffect.Click).node.id)
    }

    @Test
    fun clicksSubmitOnlyWhenQuantityIsClearlyOne() {
        val engine = engineAtCheckout()
        val checkout = snapshot(
            UiNode("quantity", "", "数量 1", false, true),
            node("submit", "提交订单"),
        )

        val effect = engine.onSnapshot(checkout, saleAt + 500)

        assertEquals("submit", (effect as EngineEffect.Click).node.id)
        assertEquals(TaskStatus.Submitting, engine.status)
    }

    @Test
    fun recognizesQuantityWithChineseColon() {
        val engine = engineAtCheckout()
        val checkout = snapshot(
            UiNode("quantity", "", "数量：1", false, true),
            node("submit", "提交订单"),
        )

        val effect = engine.onSnapshot(checkout, saleAt + 500)

        assertEquals("submit", (effect as EngineEffect.Click).node.id)
    }

    @Test
    fun failsInsteadOfSubmittingWhenQuantityIsUnclear() {
        val engine = engineAtCheckout()

        val effect = engine.onSnapshot(
            snapshot(node("submit", "提交订单")),
            saleAt + 500,
        )

        assertTrue(effect is EngineEffect.Stop)
        assertEquals(TaskStatus.Failed, (effect as EngineEffect.Stop).status)
        assertTrue(effect.reason.contains("数量"))
    }

    @Test
    fun reachesAwaitingPaymentWithoutClickingPaymentButton() {
        val engine = engineAtCheckout()
        engine.onSnapshot(
            snapshot(
                UiNode("quantity", "", "数量 1", false, true),
                node("submit", "提交订单"),
            ),
            saleAt + 500,
        )

        val effect = engine.onSnapshot(
            snapshot(node("pay", "立即支付")),
            saleAt + 1_000,
        )

        assertTrue(effect is EngineEffect.Stop)
        assertEquals(TaskStatus.AwaitingPayment, (effect as EngineEffect.Stop).status)
    }

    @Test
    fun stopsOnVerificationWithoutClicking() {
        val engine = AutomationEngine()
        engine.start(task, saleAt - 15_000)

        val effect = engine.onSnapshot(
            snapshot(
                node("captcha", "请完成安全验证"),
                node("buy", "立即购买"),
            ),
            saleAt,
        )

        assertTrue(effect is EngineEffect.Stop)
        assertEquals(TaskStatus.Failed, (effect as EngineEffect.Stop).status)
    }

    @Test
    fun failsWhenScreenIsLocked() {
        val engine = AutomationEngine()
        engine.start(task, saleAt - 15_000)

        val effect = engine.onSnapshot(
            snapshot(node("buy", "立即购买"), keyguardLocked = true),
            saleAt,
        )

        assertTrue(effect is EngineEffect.Stop)
        assertEquals(TaskStatus.Failed, (effect as EngineEffect.Stop).status)
    }

    @Test
    fun waitsOnUnknownScreenInsteadOfGuessing() {
        val engine = engineAtCheckout()

        val effect = engine.onSnapshot(
            snapshot(node("unknown", "页面加载中", clickable = false)),
            saleAt + 500,
        )

        assertEquals(EngineEffect.Wait, effect)
        assertEquals(TaskStatus.Checkout, engine.status)
    }

    @Test
    fun ignoresSnapshotsFromOtherApps() {
        val engine = AutomationEngine()
        engine.start(task, saleAt - 15_000)
        val otherApp = snapshot(node("buy", "立即购买")).copy(packageName = "com.example.other")

        val effect = engine.onSnapshot(otherApp, saleAt)

        assertEquals(EngineEffect.Wait, effect)
        assertEquals(TaskStatus.LaunchingTaobao, engine.status)
    }

    private fun engineAtCheckout(): AutomationEngine {
        val engine = AutomationEngine()
        engine.start(task, saleAt - 15_000)
        engine.onSnapshot(snapshot(node("buy", "立即购买")), saleAt)
        val skuPage = snapshot(
            node("sku", "黑色 / 256GB"),
            node("confirm", "确定"),
        )
        engine.onSnapshot(skuPage, saleAt + 100)
        engine.onSnapshot(skuPage, saleAt + 200)
        return engine
    }
}
